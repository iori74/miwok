package com.example.android.miwok;

import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class NumbersActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_numbers);
        ArrayList<Word> words = new ArrayList<Word>();
        words.add(new Word("one","lutti")) ;
        words.add(new Word("Two","otiiko")) ;
        words.add(new Word("Three","tolookusu")) ;
        words.add(new Word("four","oyyisa")) ;
        words.add(new Word("five","massokka")) ;
        words.add(new Word("six","temmokka")) ;
        words.add(new Word("seven","kenekaku")) ;
        words.add(new Word("eight","kawinta")) ;
        words.add(new Word("nine","wo'e")) ;
        words.add(new Word("ten","na' aacha")) ;

        WordAdapter Adapter = new WordAdapter(this, words);

        ListView listView = (ListView) findViewById(R.id.list);

        listView.setAdapter(Adapter);

    }
}