package com.example.android.quakereport;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class EarthQuakeAdapter extends ArrayAdapter<EarthQuake> {


    public EarthQuakeAdapter( Context context,  ArrayList<EarthQuake> earthQuakes) {
        super(context, 0, earthQuakes);
    }


    @Override
    public View getView(int position, View View, ViewGroup parent) {
        if (View == null) {
            View = LayoutInflater.from(getContext()).inflate(
                    R.layout.earthquake_list, parent, false);
        }
        EarthQuake currentEarthQuake = getItem(position);
        TextView amplitude = (TextView) View.findViewById(R.id.amplitude);
        amplitude.setText(currentEarthQuake.getAmplitude());

        TextView cityName = (TextView) View.findViewById(R.id.city_name);
        cityName.setText(currentEarthQuake.getCityName());

        TextView date = (TextView) View.findViewById(R.id.Date);
        date.setText(currentEarthQuake.getDate());
        return View;
    }
}
