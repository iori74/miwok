package com.example.android.quakereport;

public class EarthQuake {
    private final String mAmplitude;
    private final String mCityName;
    private final String mDate;

    public EarthQuake(String amplitude, String cityName,String date) {
        mAmplitude = amplitude;
        mCityName = cityName;
        mDate = date;
    }

    public String getAmplitude() {
        return mAmplitude;
    }

    public String getCityName() {
        return mCityName;
    }

    public String getDate() {
        return mDate;
    }
}
